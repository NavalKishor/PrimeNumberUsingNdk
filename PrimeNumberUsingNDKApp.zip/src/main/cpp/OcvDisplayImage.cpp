//
// Created by m1035364 on 20/3/18.
//

#include "OcvDisplayImage.h"
//#include "highgui.h"
OcvDisplayImage::OcvDisplayImage(char **argv) {
    OcvDisplayImage::argv=argv;
}

void OcvDisplayImage::displayImage(){
//    IplImage* img = cvLoadImage( argv[1] );
//    cvNamedWindow( "Example1", CV_WINDOW_AUTOSIZE );
//    cvShowImage( "Example1", img );
//    cvWaitKey(0);
//    cvReleaseImage( &img );
//    cvDestroyWindow( "Example1" );
}