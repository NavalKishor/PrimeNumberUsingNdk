//
// Created by m1035364 on 20/3/18.
//

#ifndef PRIMENUMBERUSINGNDK_OCVDISPLAYIMAGE_H
#define PRIMENUMBERUSINGNDK_OCVDISPLAYIMAGE_H


class OcvDisplayImage {
    char** argv;
public:
    OcvDisplayImage( char** argv);
    void displayImage();
};


#endif //PRIMENUMBERUSINGNDK_OCVDISPLAYIMAGE_H