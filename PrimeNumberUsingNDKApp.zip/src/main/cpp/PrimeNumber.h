//
// Created by m1035364 on 15/3/18.
//

#ifndef PRIMENUMBERUSINGNDK_PRIMENUMBER_H
#define PRIMENUMBERUSINGNDK_PRIMENUMBER_H


class PrimeNumber {
int number;
public:
    PrimeNumber(int x);
    bool isPrime();
};


#endif //PRIMENUMBERUSINGNDK_PRIMENUMBER_H
