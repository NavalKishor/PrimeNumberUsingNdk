package math.reader;

import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
public interface Api
{
    /**the base URL for our API mean server ip  */

    String BASE_URL_PC_Server = "http://192.168.0.5:8050/";//my virus
//    String BASE_URL_PC_Server = "http://192.168.1.100:8050/"; //sir airtel
    /**this is our multipart request
       we have one parameter on is sampleFile  */
    @Multipart
    @POST("upload")
    Call<MyResponse> uploadImage(@Part("sampleFile\"; filename=\"myfile.png\" ") RequestBody file);

}
