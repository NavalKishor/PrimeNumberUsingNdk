package math.reader;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;
import org.dom4j.tree.DefaultElement;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class DOM4JParserDemo {

    public static void DOM4JQuery(InputStream inputFile ) {

        try {
//            File inputFile = new File("input.txt");
            SAXReader reader = new SAXReader();
//            Document document = reader.read( inputFile );
            Document document = reader.read( inputFile );

            System.out.println("Root element :" + document.getRootElement().getName());

            Element classElement = document.getRootElement();

            List<Node> nodes = document.content();
            nodes =  ((DefaultElement) nodes.get(0)).content();;
            System.out.println("----------------------------");
            StringBuffer stringBuffer=new StringBuffer();
            StringBuffer stringBuffer2=new StringBuffer();
            for (Node node : nodes) {
                String name=node.getName();
                if (name!=null)
                {
                    stringBuffer2.append(name).append("->");
                    if ("msup".equalsIgnoreCase(name))
                    {

                    }
                    String value=node.getStringValue();
                    if (value!=null)
                    {
                        value=value.trim();
                        stringBuffer.append(value);
                    }
                }
            }
            System.out.println("name : \n" +stringBuffer2.toString()+"nameValue : \n" +stringBuffer.toString());
        } catch (DocumentException e) {
            e.printStackTrace();
        }

    }
}
