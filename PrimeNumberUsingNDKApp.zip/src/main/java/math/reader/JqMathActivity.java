package math.reader;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

import java.io.IOException;

import primeno.naval.com.primenumberusingndk.R;

public class JqMathActivity extends AppCompatActivity
{

    private WebView articleContent;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jq_math);
        articleContent = (WebView) findViewById(R.id.formula_page);
        articleContent.getSettings().setJavaScriptEnabled(true);
        articleContent.getSettings().setBuiltInZoomControls(true);
        try {
            articleContent.loadUrl("file:///android_asset/samplemath.html");
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
