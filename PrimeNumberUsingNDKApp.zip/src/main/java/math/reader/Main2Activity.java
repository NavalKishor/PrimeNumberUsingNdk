package math.reader;

import android.content.res.AssetManager;
import android.speech.tts.TextToSpeech;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.DragEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Scroller;
import android.widget.TextView;

//import org.json.XML;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.speech.*;
import javax.speech.synthesis.*;

import butterknife.BindView;
import butterknife.ButterKnife;
import primeno.naval.com.primenumberusingndk.R;

public class Main2Activity extends AppCompatActivity implements TextToSpeech.OnInitListener
{
    private static final String TAG = "Main2Activity";
    @BindView(R.id.editText)
    EditText editText;
    @BindView(R.id.linearLayout)
    LinearLayout linearLayout;
    @BindView(R.id.linearLayout1)
    LinearLayout linearLayout1;
    @BindView(R.id.linearLayout2)
    LinearLayout linearLayout2;
    @BindView(R.id.linearLayout3)
    LinearLayout linearLayout3;
    @BindView(R.id.textView)
    TextView textView;
    @BindView(R.id.textView2)
    TextView textView2;
    @BindView(R.id.textView3)
    TextView textView3;
    @BindView(R.id.textView4)
    TextView textView4;
    SaxParserHandler defaultHandler;
    Properties properties;
    private TextToSpeech tts;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        ButterKnife.bind(this);
        tts = new TextToSpeech(this, this);
        linearLayout.setOnDragListener(onDragListener);
        linearLayout1.setOnDragListener(onDragListener);
        linearLayout2.setOnDragListener(onDragListener);
        linearLayout3.setOnDragListener(onDragListener);
        textView.setOnTouchListener(onTouchListener);
        textView2.setOnTouchListener(onTouchListener);
        textView3.setOnTouchListener(onTouchListener);
        textView4.setOnTouchListener(onTouchListener);
        textView.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
              //  parseSAXFile("mathml.xml");
               // parseSAXFile("quadraticformula.xml");
                speakOut();
            }
        });
        textView.setTag("Text 1");
        textView2.setTag("Text 2");
        textView3.setTag("Text 3");
        textView4.setTag("Text 4");
        editText.setScroller(new Scroller(this));
        editText.setMaxLines(10);
        editText.setVerticalScrollBarEnabled(true);
        editText.setMovementMethod(new ScrollingMovementMethod());

        try
        {
            //mapping logic
            properties = new Properties();
            AssetManager assetManager = getAssets();
            InputStream inputStream;
            inputStream = assetManager.open("map.properties");
            properties.load(inputStream);
            ParserMangers.getParserManger().loadMapProperties(properties,inputStream);
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

        String xmlString = "<?xml version=\"1.0\" encoding=\"utf-8\"?>" +
                "<math xmlns=\"http://www.w3.org/1998/Math/MathML\"><mi>a</mi>" +
                "<msup><mi>x</mi><mn>2</mn></msup><mo>+</mo><mi>b</mi><mi>x</mi>" +
                "<mo>+</mo><mi>c</mi><mo>=</mo>" +
                "<msup><mrow><mfenced >" +
                "<mrow><mn>1</mn><mo>+</mo><mn>2</mn><mi>x</mi>" +
                "</mrow></mfenced></mrow><mrow>" +
                "<mn>2</mn></mrow></msup>" +
                "<mo>=</mo>"+
                "<mfrac><mrow><mn>1</mn></mrow><mrow><mn>2</mn></mrow></mfrac>"+
                "</math>";
        try
        {
            //String soapmessageString = "<xml>yourStringURLorFILE</xml>";
           // JSONObject soapDatainJsonObject  = XML.toJSONObject(xmlString);
            //System.out.println(soapDatainJsonObject);
            InputStream is = getApplicationContext().getAssets().open("mathml.xml");
            XMLtoJsonConverter xmLtoJsonConverter =new XMLtoJsonConverter();
            xmLtoJsonConverter.getXMLfromJson(is);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        editText.setText(Html.fromHtml(xmlString));
        defaultHandler = new SaxParserHandler();
        parseGeneric(xmlString);
        parseSAXString(xmlString);



        //parseSAXString(xmlString);

        parseSAXFile("mathml.xml");
        parseSAXFile("quadraticformula.xml");
        parseSAXFile("whole.xml");
        String tetx=parseGenerics("mathml.xml");
         tetx+="\nquadraticformula\n"+parseGenerics("quadraticformula.xml");
         tetx+="\nwhole\n"+parseGenerics("whole.xml");
        editText.setText(editText.getText().toString()+"\n\nlatest\n"+tetx);
        //parseGenerics("qa.xml");
        DOM4JQueryFile("qa.xml");



        String mlfor="<math xmlns=\"http://www.w3.org/1998/Math/MathML\"><mo>(</mo><mn>1</mn><mo>+</mo><msup><mi>x</mi><mn>2</mn></msup><msup><mo>)</mo><mn>2</mn></msup></math>";
        parseSAXString(mlfor);
//        String msup2in="<math xmlns=\"http://www.w3.org/1998/Math/MathML\"><msup><mfenced><mrow><mn>1</mn><mo>+</mo><msup><mi>x</mi><mn>2</mn></msup></mrow></mfenced><mn>2</mn></msup></math>";
//        parseSAXString(msup2in);
//  parseGenerics("whole.xml");
        // speakOut();
        //test(editText.getText().toString().split("\n"));

    }

    @Override
    protected void onDestroy()
    {
        // Don't forget to shutdown tts!
        if (tts != null)
        {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }

    public void parseGeneric(String xmlstring)
    {

        try
        {
            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            //InputStream is = getApplicationContext().getAssets().open("mathml.xml");
            DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
            InputSource is = new InputSource();
            is.setCharacterStream(new StringReader(xmlstring));
            Document document = docBuilder.parse(is);
//            Document document = docBuilder.parse(args);

            NodeList nodeList = document.getElementsByTagName("*");
            System.out.println("---Node");
            for (int i = 0; i < nodeList.getLength(); i++)
            {
                Node node = nodeList.item(i);
                if (node.getNodeType() == Node.ELEMENT_NODE)
                {
                    System.out.println(node.getNodeName());

                    get(node);
                }
            }
            System.out.println("Node---");
        }
        catch (ParserConfigurationException e)
        {
            e.printStackTrace();
        }
        catch (SAXException e)
        {
            e.printStackTrace();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    public String get(Node  node)
    {
        Element element= (Element)node;
        String result=null;
        switch (node.getNodeName())
        {
            case "msup":
                NodeList msupChilds = element.getChildNodes();
                StringBuilder stringBuilder=new StringBuilder();
                for (int i = 0; i < msupChilds.getLength(); i++)
                {
                    Node cn = msupChilds.item(i);
                    if (msupChilds.item(i) instanceof Element)
                    {
                        System.out.println(cn.getNodeName());
                      String s=  get(cn);
                      stringBuilder.append(s).append("\n");
                    }

                }
                String[] strings=stringBuilder.toString().split("\n");


                System.out.println("msup:->"+stringBuilder);
                break;
            case "mfrac": break;
            case "msqrt": break;
            case "mroot": break;
            case "mfenced": break;
            case "msubsup": break;
            case "munder": break;
            case "msub": break;
            case "mover": break;
            case "munderover": break;
            case "mtable": break;
            case "mi": case "mo":
            case "mn":
                result= node.getChildNodes().item(0).getNodeValue();

            break;
        }
        return result;
    }

    public static String getFrac(NodeList nodeList,Node  node)
    {
        return TAG;
    }

    public void DOM4JQueryFile(String xmlstring)
    {

        try
        {
            //File inputFile = new File("input.txt");
            InputStream inputFile = getApplicationContext().getAssets().open(xmlstring);
            DOM4JParserDemo.DOM4JQuery(inputFile);
//            SAXReader reader = new SAXReader();
//            org.dom4j.Document document = reader.read( inputFile );
//
//            System.out.println("Root element :" + document.getRootElement().getName());
//
//            org.dom4j.Element classElement = document.getRootElement();
//
//            List<org.dom4j.Node> nodes = document.selectNodes("math" );
//            System.out.println("----------------------------");
//
//            for (org.dom4j.Node node : nodes) {
//                System.out.println("\nCurrent Node Name :"  + node.getName());
//               // System.out.println("Student roll no : "+ node.valueOf("@rollno") );
//                System.out.println("Vaule Name : " + node.selectSingleNode(node.getName()).getText());
//
//            }
        }
//        catch (org.dom4j.DocumentException e) {
//            e.printStackTrace();
//        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

    }

    public String parseGenerics(String xmlstring)
    {

        StringBuffer stringBuffer=new StringBuffer();
        try
        {
            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
           // docBuilderFactory.setValidating(true);
           // docBuilderFactory.setIgnoringElementContentWhitespace(true);
            InputStream is = getApplicationContext().getAssets().open(xmlstring);
            DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
            // InputSource is = new InputSource();
            // is.setCharacterStream(new StringReader(xmlstring));
            Document document = docBuilder.parse(is);
            //  document.getDocumentElement().normalize();
            //            Document document = docBuilder.parse(args);
          List<String> singleTextChild= Arrays.asList(new String[]{"math","mi","mo","mn","mtext","mstring"});
            NodeList nodeList = document.getElementsByTagName("*");
            System.out.println("---Node---\n");

            StringBuffer stringBuffer2=new StringBuffer();
            for (int i = 0; i < nodeList.getLength(); i++)
            {
                Node node = nodeList.item(i);
                if (node.getNodeType() == Node.ELEMENT_NODE)
                {
                   // stringBuffer.append(node.getNodeName()).append("->");
                    switch (node.getNodeName())
                    {
                        case "math":
//                            String mMathVal=ParserMangers.MMath(node);
//                            System.out.println("math:"+mMathVal);
                            break;
                        case "mfrac":
                            String result=ParserMangers.MFrac(node);
                            stringBuffer.append(" ").append(result);

                            break;
                        case "msqrt":
                           // stringBuffer.append(" square root of ");
                            String mSqrtVal=ParserMangers.MSqrt(node);
                            stringBuffer.append(" ").append(mSqrtVal);
                            break;
                        case "mfenced":
                            String mFenceVal=ParserMangers.MFenced(node);
                            stringBuffer.append(" ").append(mFenceVal);
                           /*
                            NamedNodeMap namedNodeMap=node.getAttributes();
                            if (namedNodeMap.getLength()>=2)
                            {
                                Node mfenceOpen=namedNodeMap.getNamedItem("open");
                                if (mfenceOpen!=null)
                                {
                                    String open=mfenceOpen.getTextContent();
                                    stringBuffer.append(" ").append(properties.getProperty(open));
                                }
                                // closing logic need to decide
                                Node mfenceClose=namedNodeMap.getNamedItem("close");
                                if (mfenceClose!=null)
                                {
                                    String close=mfenceClose.getTextContent();
                                    stringBuffer.append(" ").append(properties.getProperty(close));
                                }
                            }
                            */
                            break;
                        case "munder":
                        case "msub":
                            String msubVal=ParserMangers.MSub(node);
                            stringBuffer.append(" ").append(msubVal);
                            break;
                        case "mroot":
                        case "msup":
                        case "mover":
                        String msupVal=ParserMangers.MSup(node);
                        stringBuffer.append(" ").append(msupVal);
                            break;
                        case "munderover":
                        case "msubsup":
                            String msubsupVal=ParserMangers.MSubSup(node);
                            stringBuffer.append(" ").append(msubsupVal);
                            break;
                        //case "munder": break;
                        //case "mover": break;
                        //case "munderover":break;
                        case "mtable":  String mTableVal=ParserMangers.MTable(node);
                            stringBuffer.append(" ").append(mTableVal);
                            break;
                        case "matrix": String mTabVal=ParserMangers.MMatrix(node);
                            stringBuffer.append(" ").append(mTabVal);
                            break;
                        case "mrow":String mrowVal=ParserMangers.MRow(node);
                            stringBuffer.append(" ").append(mrowVal);
                            break;
                        case "matrixrow":case "mtr": ParserMangers.MMatrixCol(node);break;
                        case "mi": case "mo": case "mn": case "mtext":case "mstring":case "cn":case "mtd":
                        case "#text": case "#string":case "string":case "text":
                        String nodVal=node.getTextContent();
                        if(node.getNodeName().equalsIgnoreCase("mo"))
                            nodVal=properties.getProperty(nodVal,nodVal);
                        stringBuffer.append(" ").append(nodVal);
                            break;
                        case "#comment":break;
                    }
                  //  if(Arrays.asList(new String[]{"mi","mo","mn","mtext","mstring"}).stream().filter(tagName->node.getNodeName().equalsIgnoreCase(tagName)).findAny().isPresent())
                    if(!singleTextChild.contains(node.getNodeName()))
                       i+=ParserMangers.getTotalChildCount(node);
                }

            }

//            System.out.println("nameValue:"+stringBuffer2.toString()+"\n");
            System.out.println("name:"+stringBuffer.toString()+"\n---Node---");

        }
        catch (ParserConfigurationException e)
        {
            e.printStackTrace();
        }
        catch (SAXException e)
        {
            e.printStackTrace();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        return stringBuffer.toString();
    }

    public void parseSAXString(String xmlstring)
    {
        SAXParserFactory factory = SAXParserFactory.newInstance();

        try
        {
            SAXParser saxParser = factory.newSAXParser();
            XMLReader xr = saxParser.getXMLReader();
            xr.setContentHandler(defaultHandler);
            InputSource inStream = new InputSource();
            inStream.setCharacterStream(new StringReader(xmlstring));
            xr.parse(inStream);
            editText.setText(editText.getText().toString() + "\n" + defaultHandler.getVal() + "\n");
            // speakOut();
        }
        catch (ParserConfigurationException e)
        {
            e.printStackTrace();
        }
        catch (SAXException e)
        {
            e.printStackTrace();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

    }

    public void parseSAXFile(String xmlfileNameInAssest)
    {
        try
        {
            SAXParserFactory factory = SAXParserFactory.newInstance();
            SAXParser saxParser = factory.newSAXParser();
            XMLReader xr = saxParser.getXMLReader();
            xr.setContentHandler(defaultHandler);

            InputStream is = getApplicationContext().getAssets().open(xmlfileNameInAssest);
            xr.parse(new InputSource(is));
            editText.setText(editText.getText().toString() + "\n" + defaultHandler.getVal() + "\n");
            // speakOut();
        }
        catch (ParserConfigurationException e)
        {
            e.printStackTrace();
        }
        catch (SAXException e)
        {
            e.printStackTrace();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

    }

    public static void parseXML(String xmlstring)
    {

    }

    View.OnTouchListener onTouchListener = new View.OnTouchListener()
    {
        @Override
        public boolean onTouch(View view, MotionEvent motionEvent)
        {
            if (motionEvent.getAction() == MotionEvent.ACTION_DOWN)
            {
                View.DragShadowBuilder shadowBuilder = new View.DragShadowBuilder(view);
                view.startDrag(null, shadowBuilder, view, 0);
                view.setVisibility(View.GONE);
                return true;
            }
            else
            {
                view.setVisibility(View.VISIBLE);
                return false;
            }
//            return false;
        }
    };

    View.OnDragListener onDragListener = new View.OnDragListener()
    {
        @Override
        public boolean onDrag(View layoutview, DragEvent dragEvent)
        {
            int action = dragEvent.getAction();
            switch (action)
            {
                case DragEvent.ACTION_DRAG_STARTED:
                    Log.d(TAG, "Drag event started");
                    break;
                case DragEvent.ACTION_DRAG_ENTERED:
                    Log.d(TAG, "Drag event entered into " + layoutview.toString());
                    break;
                case DragEvent.ACTION_DRAG_EXITED:
                    Log.d(TAG, "Drag event exited from " + layoutview.toString());
                    break;
                case DragEvent.ACTION_DROP:
                    Log.d(TAG, "Dropped");

                    View view = (View) dragEvent.getLocalState();
                    ViewGroup owner = (ViewGroup) view.getParent();
                    owner.removeView(view);
                    view.setOnTouchListener(null);
                    LinearLayout container = (LinearLayout) layoutview;
                    container.addView(view);
                    view.setVisibility(View.VISIBLE);
                    ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) container.getLayoutParams();
                    layoutParams.height = ConstraintLayout.LayoutParams.WRAP_CONTENT;
                    break;
                case DragEvent.ACTION_DRAG_ENDED:
                    Log.d(TAG, "Drag ended");
                    view = (View) dragEvent.getLocalState();
                    view.setVisibility(View.VISIBLE);
                    break;
                default:
                    break;
            }
            return true;
        }
    };

    @Override
    public void onInit(int status)
    {
        if (status == TextToSpeech.SUCCESS)
        {

            int result = tts.setLanguage(Locale.US);

            if (result == TextToSpeech.LANG_MISSING_DATA
                    || result == TextToSpeech.LANG_NOT_SUPPORTED)
            {
                Log.e("TTS", "This Language is not supported");
            }
            else
            {
                // btnSpeak.setEnabled(true);
                speakOut();
            }

        }
        else
        {
            Log.e("TTS", "Initilization Failed!");
        }

    }

    private void speakOut()
    {

        String text = editText.getText().toString();

        tts.speak(text + " ", TextToSpeech.QUEUE_FLUSH, null);
    }

    class SaxParserHandler extends DefaultHandler
    {

        StringBuilder builder = new StringBuilder();

        private String tempVal, fracFirstTag;
        private StringBuilder ValinMidle, ValSubSup, ValFrac;
        boolean isSup, isSqrt, isFrac, isSubSup;
        int subSup = 0, frac = 0, sqrt = 0, sup = 0;

        public String getVal()
        {

//            int index = builder.indexOf("to the power of 2");
//            if (index > -1)
//                builder.replace(index, (index + ("to the power of 2".length())), " square ");
//            index = builder.indexOf("to the power of 3");
//            if (index > -1)
//                builder.replace(index, (index + ("to the power of 3".length())), " cube ");

            String result=  builder.toString();
            result=result.replace("(",properties.getProperty("(")).replace(")",properties.getProperty(")"));
            result=result.replace("{",properties.getProperty("{")).replace("}",properties.getProperty("}"));
            result=result.replace("[",properties.getProperty("[")).replace("]",properties.getProperty("]"));
            result= result.replace("closing parenthesis to the power of 2","closing parenthesis whole square ");
            result=result.replace("closing parenthesis to the power of 2","closing parenthesis whole square ");
            result=result.replace("to the power of 2"," square ");
            result=result.replace("closing parenthesis to the power of 3","closing parenthesis whole cube ");
            result=result.replace("to the power of 3"," cube ");
            result=result.replaceAll("-", " minus ");
            result=result.replaceAll("   ", " ");
            return result;
        }


        Attributes attribute;
        String close;
        @Override
        public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException
        {
            super.startElement(uri, localName, qName, attributes);
            // Log.d(TAG, "startElement:\nuri " + uri + ",\nlocalName:" + localName + "\nqName:" + qName + "\nattributes:" + attributes);
            attribute=attributes;
            // reset
            tempVal = "";
            if (qName.equalsIgnoreCase("math"))
            {
                builder = new StringBuilder();
            }
            String append = properties.getProperty(qName);
            if (append != null && qName.equalsIgnoreCase("mfenced"))
            {
                 append="opening " + append;
                 close=attribute.getValue("close");
                String open=attributes.getValue("open");
                if(open!=null&&!open.isEmpty()) append=properties.getProperty(open);
                builder.append(append);
            }
            if (append != null && qName.equalsIgnoreCase("msqrt"))
            {

                builder.append(append);
                isSqrt = true;
            }
            if (qName.equalsIgnoreCase("msup"))
            {
                isSup = true;
                ValinMidle = new StringBuilder();
                ValinMidle.append(append);
            }
            if (qName.equalsIgnoreCase("msubsup"))
            {
                isSubSup = true;
                ValSubSup = new StringBuilder();
                //ValSubSup.append(append);
            }
            if (qName.equalsIgnoreCase("mfrac"))
            {
                isFrac = true;

                builder.append(append);
                return;
            }
            if (isSubSup)
            {
                if (!(qName.equalsIgnoreCase("msubsup") || qName.equalsIgnoreCase("mi") ||
                        qName.equalsIgnoreCase("mo") || qName.equalsIgnoreCase("mn")))
                    subSup++;
            }
            if (isSup)
            {
                if (!(qName.equalsIgnoreCase("msup") || qName.equalsIgnoreCase("mi") ||
                        qName.equalsIgnoreCase("mo") || qName.equalsIgnoreCase("mn")))
                    sup++;
            }

            if (isFrac)
            {
                // Log.i(TAG, "isFrac-->startElement: " + qName);
                fracFirstTag = qName;
                isFrac = false;
            }
        }

        @Override
        public void endElement(String uri, String localName, String qName) throws SAXException
        {
            super.endElement(uri, localName, qName);
            String append = properties.getProperty(qName);
            if (isSup)
            {
                if (sup == 0)
                {
                    ValinMidle.insert(0,  tempVal+" " );

                    builder.append(ValinMidle.toString());

                    isSup = false;
                    tempVal=null;
                    //ValinMidle.delete(0,ValinMidle.length());
                    ValinMidle = null;
                    return;

                }
                else
                {

                    if ((qName.equalsIgnoreCase("mi") || qName.equalsIgnoreCase("mn")
                            || qName.equalsIgnoreCase("mo")))
                    {// ValinMidle.append( tempVal + " ");
                        builder.append(tempVal).append(" ");
                        tempVal = null;
                        return;
                    }
                    else
                    {
                        if (sup == 1)
                        {                      //  ValinMidle.append(append);
                            builder.append(properties.getProperty("msup"));
                            isSup = false;
                            sup = 0;
                        }
                        else
                        {
                            sup--;
                        }
                        // builder.append(ValinMidle.toString());//isSup = false;//ValinMidle.delete(0,ValinMidle.length());// ValinMidle = null;
                    }
                }
            }

            if (isSubSup)
            {
                if ((qName.equalsIgnoreCase("mi") || qName.equalsIgnoreCase("mn")
                        || qName.equalsIgnoreCase("mo")))
                {
                    // if(subSup==1)
                    // ValSubSup.insert(0, " " + tempVal + " ");
                    //  isSubSup = false;

                    builder.append(tempVal);
                    //ValinMidle.delete(0,ValinMidle.length());
                    //ValSubSup = null;
                    tempVal = null;
                    return;
                }
                else
                {
                    if (subSup == 1)
                    {                      //  ValinMidle.append(append);
                        builder.append(" as lower bound of summation and upper bound of summation is ");
                        isSubSup = false;
                        subSup = 0;
                    }
                    else
                    {
                        subSup--;
                    }
                }
            }

            if (qName.equalsIgnoreCase(fracFirstTag))
            {

                builder.append(tempVal + " and by ");
                isSqrt = false;
                fracFirstTag = null;
                tempVal=null;
                return;

            }

            if (append != null && qName.equalsIgnoreCase("mfenced"))
            {
               // String close=attribute.getValue("close");
                  append="closing " + append;
                 if(close!=null&&!close.isEmpty()) append=properties.getProperty(close);
                 builder.append(append);
                close=null;
                return;
            }
            if (tempVal != null && !tempVal.trim().isEmpty())
            {
                builder.append(tempVal).append(" ");
                tempVal="";
            }
            // Log.d(TAG, "endElement:\nuri:" + uri + ",\nlocalName:" + localName + "\nqName:" + qName + "\nValue:" + tempVal);
        }

        @Override
        public void characters(char[] ch, int start, int length) throws SAXException
        {
            super.characters(ch, start, length);
            tempVal = new String(ch, start, length);
        }
    }

    public void test(String args[])
    {
        try
        {
            Synthesizer synth = Central.createSynthesizer(new SynthesizerModeDesc());
            synth.allocate();
            synth.resume();
//            synth.speak(new File(args[0]).toURI().toURL(), null);
            synth.speak(args[0], null);
            synth.waitEngineState(Synthesizer.QUEUE_EMPTY);
            synth.deallocate();
        }
        catch (Exception e)
        {
            System.err.print("--- ERROR --- ");
            e.printStackTrace();
        }
    }

}
