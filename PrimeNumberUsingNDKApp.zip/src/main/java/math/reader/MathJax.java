package math.reader;

import android.annotation.SuppressLint;
import android.app.Fragment;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.support.v4.app.*;
import android.widget.Toast;
import android.content.res.*;
import android.net.*;

import java.io.IOException;
import java.net.*;

import fmath.conversion.ConvertFromLatexToMathML;
import fmath.conversion.ConvertFromMathMLToLatex;
import primeno.naval.com.primenumberusingndk.R;
import uk.ac.ed.ph.snuggletex.SnuggleEngine;
import uk.ac.ed.ph.snuggletex.SnuggleInput;
import uk.ac.ed.ph.snuggletex.SnuggleSession;

public class MathJax extends AppCompatActivity implements View.OnClickListener,URLDialog.FragToActivityImpl
{

    SharedPreferences prefs;
    final int MJ_DIALOG_ID = 1;
    private int exampleIndex = 0;
    private boolean mmltoggle = false;
    URLDialog MJURLDialog;
    WebView w;
    EditText e;

    @SuppressLint("JavascriptInterface")
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_math_jax);
        w = (WebView) findViewById(R.id.webview);
        w.getSettings().setJavaScriptEnabled(true);
        w.getSettings().setBuiltInZoomControls(true);
        w.loadDataWithBaseURL("http://bar/", "<script type='text/x-mathjax-config'>"
                +"MathJax.Hub.Config({ "
                +"showMathMenu: false, "
                +"jax: ['input/TeX','output/HTML-CSS', 'output/CommonHTML'], " // output/SVG
                +"extensions: ['tex2jax.js','toMathML.js','MathMenu.js','MathZoom.js'], "
                +"tex2jax: { inlineMath: [ ['$','$'] ], processEscapes: true },"
                +"TeX: { extensions: ['AMSmath.js','AMSsymbols.js','noErrors.js','noUndefined.js'] }, "
                //+"'SVG' : { blacker: 30, "
                // +"styles: { path: { 'shape-rendering': 'crispEdges' } } } "
                +"});</script>"
                +"<script type='text/javascript' src='file:///android_asset/MathJax/MathJax.js'></script>"
                +"<script type='text/javascript'>getLiteralMML = function() {"
                +"math=MathJax.Hub.getAllJax('math')[0];"
                // below, toMathML() rerurns literal MathML string
                +"mml=math.root.toMathML(''); return mml;"
                +"}; getEscapedMML = function() {"
                +"math=MathJax.Hub.getAllJax('math')[0];"
                // below, toMathMLquote() applies &-escaping to MathML string input
                +"mml=math.root.toMathMLquote(getLiteralMML()); return mml;}"
                +"</script>"
                +"<span id='text'>Formula:</span><span id='math'></span><pre><span id='mmlout'></span></pre>","text/html","utf-8","");
        w.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (!url.startsWith("http://bar")) return;
                e.setText(getExample(exampleIndex++));
                if (exampleIndex > getResources().getStringArray(R.array.tex_examples).length - 1) exampleIndex = 0;

                w.loadUrl("javascript:document.getElementById('math').innerHTML='\\\\["
                        + doubleEscapeTeX(e.getText().toString()) + "\\\\]';");
                w.loadUrl("javascript:MathJax.Hub.Queue(['Typeset',MathJax.Hub]);");
            }
        });
        w.addJavascriptInterface(new Object() { public void clipMML(String s) {
            WebView ww = (WebView) findViewById(R.id.webview);
            //uses android.text.ClipboardManager for compatibility with pre-Honeycomb
            //for HC or later, use android.content.ClipboardManager
            android.text.ClipboardManager clipboard = (android.text.ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            //next 2 comment lines have HC or later code, can also try newHtmlText()
            //ClipData clip = ClipData.newPlainText("MJ MathML text",s);//,s);
            //clipboard.setPrimaryClip(clip);
            // literal MathML (in parameter s) placed on system clipboard
            clipboard.setText(s);
            Log.i("TAG", this.getClass().getSimpleName() + "-->clipMML: "+s);
            Toast.makeText(getApplicationContext(),"MathML copied to clipboard",Toast.LENGTH_SHORT).show();
        }}, "injectedObject");
          e = (EditText) findViewById(R.id.edit);
        e.setBackgroundColor(Color.LTGRAY);
        e.setTextColor(Color.BLACK);
        e.setText("");
        Button b = (Button) findViewById(R.id.button2);
        b.setOnClickListener(this);
        b = (Button) findViewById(R.id.button3);
        b.setOnClickListener(this);
        b = (Button) findViewById(R.id.button4);
        b.setOnClickListener(this);
        b = (Button) findViewById(R.id.button5);
        b.setOnClickListener(this);
        TextView t = (TextView) findViewById(R.id.textview3);
        t.setMovementMethod(LinkMovementMethod.getInstance());
        t.setText(Html.fromHtml(t.getText().toString()));
        prefs = getPreferences(MODE_PRIVATE);
        if (prefs.getString("MathJaxURL","").length() == 0) {
            SharedPreferences.Editor editprefs = prefs.edit();
            editprefs.putString("MathJaxURL", getResources().getString(R.string.mjurl));
            editprefs.commit();
        }
        setURL(prefs.getString("MathJaxURL", getResources().getString(R.string.mjurl)));
        MJURLDialog =  URLDialog.newInstance();
        MJURLDialog.setFragToActivity(this);
        MJURLDialog.setPrefs(prefs);
    }

    private String doubleEscapeTeX(String s) {
        String t="";
        for (int i=0; i<s.length(); i++) {
            if (s.charAt(i) == '\'') t += '\\';
            if (s.charAt(i) != '\n') t += s.charAt(i);
            if (s.charAt(i) == '\\') t += "\\";
        }
        return t;
    }
    public void setURL(String newurl) {
        SharedPreferences.Editor editprefs = prefs.edit();
        editprefs.putString("MathJaxURL", newurl);
        editprefs.commit();
        WebView w = (WebView) findViewById(R.id.webview);
        w.loadDataWithBaseURL("http://bar","<script type='text/javascript' "
                +"src='"+newurl+"'"
                +"></script><span id='text'>Formula:</span><span id='math'></span>","text/html","utf-8","");
    }
    public void setDefaultURL() {
        setURL(getResources().getString(R.string.mjurl));
    }


    private String getExample(int index) {
        return getResources().getStringArray(R.array.tex_examples)[index];
    }

    public void onClick(View v) {
        /*if (v == findViewById(R.id.button2)) {
            WebView w = (WebView) findViewById(R.id.webview);
            EditText e = (EditText) findViewById(R.id.edit);
            mmltoggle=false;
            w.loadUrl("javascript:document.getElementById('mmlout').innerHTML='';");
            w.loadUrl("javascript:document.getElementById('math').innerHTML='\\\\["
                    +doubleEscapeTeX(e.getText().toString())+"\\\\]';");
            w.loadUrl("javascript:MathJax.Hub.Queue(['Typeset',MathJax.Hub]);");
        }
        else if (v == findViewById(R.id.button3)) {
            WebView w = (WebView) findViewById(R.id.webview);
            EditText e = (EditText) findViewById(R.id.edit);
            mmltoggle=false;
            e.setText("");
            w.loadUrl("javascript:document.getElementById('mmlout').innerHTML='';");
            w.loadUrl("javascript:document.getElementById('math').innerHTML='';");
        }
        else if (v == findViewById(R.id.button4)) {
            WebView w = (WebView) findViewById(R.id.webview);
            EditText e = (EditText) findViewById(R.id.edit);
            mmltoggle=false;
            e.setText(getExample(exampleIndex++));
            if (exampleIndex > getResources().getStringArray(R.array.tex_examples).length-1)
                exampleIndex=0;
            w.loadUrl("javascript:document.getElementById('mmlout').innerHTML='';");
            w.loadUrl("javascript:document.getElementById('math').innerHTML='\\\\["
                    +doubleEscapeTeX(e.getText().toString())
                    +"\\\\]';");
            w.loadUrl("javascript:MathJax.Hub.Queue(['Typeset',MathJax.Hub]);");
        }
        else if (v == findViewById(R.id.button5)) {
            WebView w = (WebView) findViewById(R.id.webview);
            EditText e = (EditText) findViewById(R.id.edit);
            mmltoggle=!mmltoggle;
            w.loadUrl("javascript:document.getElementById('mmlout').innerHTML='';");
            // need 2 versions of the MathML
            // showMML() returns literal MathML, getMML() returns &-escaped for HTML display
            // put getMML() into innerHTML of mmlout span
            // use JS call to clipMML() method in injected Java object
            // to put showMML() into system clipboard
            if (mmltoggle) {
                // &-escaped MathML enclosed in <pre> tags in "mmlout" span for HTML display
                w.loadUrl("javascript:document.getElementById('mmlout').innerHTML = window.getEscapedMML();");
                w.loadUrl("javascript:injectedObject.clipMML(window.getLiteralMML());");
            }
        }
        */
       // WebView w = (WebView) findViewById(R.id.webview);
       // EditText e = (EditText) findViewById(R.id.edit);
        if (v == findViewById(R.id.button5)) {
            mmltoggle=!mmltoggle;
            w.loadUrl("javascript:document.getElementById('mmlout').innerHTML='';");
            // need 2 versions of the MathML
            // showMML() returns literal MathML, getMML() returns &-escaped for HTML display
            // put getMML() into innerHTML of mmlout span
            // use JS call to clipMML() method in injected Java object
            // to put showMML() into system clipboard
            if (mmltoggle) {
                // &-escaped MathML enclosed in <pre> tags in "mmlout" span for HTML display
                w.loadUrl("javascript:document.getElementById('mmlout').innerHTML = window.getEscapedMML();");
                w.loadUrl("javascript:injectedObject.clipMML(window.getLiteralMML());");
            }
            // MJURLDialog.show(getFragmentManager(),"mj_url");
            MJURLDialog.show(getSupportFragmentManager(),"mj_url");
        }
        else
        {
            if (v.getId() == (R.id.button3))
            {
                mmltoggle=false;
                e.setText("");
                w.loadUrl("javascript:document.getElementById('mmlout').innerHTML='';");
                w.loadUrl("javascript:document.getElementById('math').innerHTML='';");
               // w.loadUrl("javascript:MathJax.Hub.Queue(['Typeset',MathJax.Hub]);");
            }
            else
            {
                if (v.getId() == (R.id.button2))
                {
                    mmltoggle=false;
                    w.loadUrl("javascript:document.getElementById('mmlout').innerHTML='';");
                    w.loadUrl("javascript:document.getElementById('math').innerHTML='\\\\[" + doubleEscapeTeX(e.getText().toString()) + "\\\\]';");
                   // w.loadUrl("javascript:MathJax.Hub.Queue(['Typeset',MathJax.Hub]);");

                    String mathml = ConvertFromLatexToMathML.convertToMathML(e.getText().toString());
                    w.loadUrl("javascript:document.getElementById('math').innerHTML='"+mathml+"'");
                    Log.i("TAG",  "-->onClick: \nmathmal: "+mathml);
                }
                else if (v.getId() == (R.id.button4))
                {
                    mmltoggle=false;
                    e.setText(getExample(exampleIndex++));
                    if (exampleIndex > getResources().getStringArray(R.array.tex_examples).length - 1) exampleIndex = 0;
                    w.loadUrl("javascript:document.getElementById('mmlout').innerHTML='';");
                    w.loadUrl("javascript:document.getElementById('math').innerHTML='hello: \\\\[" + doubleEscapeTeX(e.getText().toString()) + "\\\\]';");
                   // w.loadUrl("javascript:MathJax.Hub.Queue(['Typeset',MathJax.Hub]);");
                    /* Create vanilla SnuggleEngine and new SnuggleSession */
                    SnuggleEngine engine = new SnuggleEngine();
                    SnuggleSession session = engine.createSession();

                    /* Parse some very basic Math Mode input */
//                    SnuggleInput input = new SnuggleInput("$$ x+2=3 $$");
                    SnuggleInput input = new SnuggleInput("$$ "+e.getText().toString()+" $$");

                    try
                    {
                        session.parseInput(input);
                    }
                    catch (IOException e1)
                    {
                        e1.printStackTrace();
                    }

                    /* Convert the results to an XML String, which in this case will
                     * be a single MathML <math>...</math> element. */
                    String xmlString = session.buildXMLString();
                    String latex = "default:{x}^{2} + {y}_{1} + \\sqrt{3}";
                    try
                    {
                        //latex = ConvertFromMathMLToLatex.convertToLatex(xmlString);
                    }
                    catch (Exception e1)
                    {
                        e1.printStackTrace();
                    }
                    Log.i("TAG", "\n latex:"+latex+ " \n by sunggle-->onClick:mathml "+xmlString);
                }
            }
            if (android.os.Build.VERSION.SDK_INT < 19)
            {
                w.loadUrl("javascript:MathJax.Hub.Queue(['Typeset',MathJax.Hub]);");
            }
            else {
                w.evaluateJavascript("javascript:MathJax.Hub.Queue(['Typeset',MathJax.Hub]);",null);
            }
           // w.loadUrl("javascript:MathJax.Hub.Queue(['Typeset',MathJax.Hub]);");
        }

    }






  /*  @SuppressLint("ValidFragment")
    public class URLDialog extends android.support.v7.app.AppCompatDialogFragment
    {

        public URLDialog() { }

        @Nullable
        @Override
        public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
        {
            final View view = inflater.inflate(R.layout.url_dialog, container);
            getDialog().setTitle(R.string.urltitle);
            EditText e = (EditText) view.findViewById(R.id.editurl);
            e.setText(prefs.getString("MathJaxURL",getResources().getString(R.string.mjurl)));
            Button b = (Button) view.findViewById(R.id.okbutton);
            b.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    EditText e = (EditText) view.findViewById(R.id.editurl);
                    setURL(e.getText().toString());
                    getDialog().dismiss();
                }
            });
            Button b1 = (Button) view.findViewById(R.id.defaultbutton);
            b1.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    EditText e = (EditText) view.findViewById(R.id.editurl);
                    e.setText(getResources().getString(R.string.mjurl));
                    setDefaultURL();
                }
            });
            Button b2 = (Button) view.findViewById(R.id.localbutton);
            b2.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    EditText e = (EditText) view.findViewById(R.id.editurl);
                    e.setText(getResources().getString(R.string.loopback));
                    setURL(getResources().getString(R.string.loopback));
                }
            });
            return view;//super.onCreateView(inflater, container, savedInstanceState);
        }
    }*/


}
