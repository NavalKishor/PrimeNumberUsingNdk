package math.reader;

public class MyResponse
{

    String latex;
   // boolean error;
    String mathml="";
    String finalResult="";

    @Override
    public String toString()
    {
        super.toString();
        return "MyResponse:[latex:+"+latex+",mathml:"+mathml+"]";
    }
}
