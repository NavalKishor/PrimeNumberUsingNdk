package math.reader;

import net.sf.json.JSON;
import net.sf.json.JSONObject;
import net.sf.json.xml.XMLSerializer;

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.net.URL;
import java.util.Stack;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.apache.commons.io.*;

public class ParserManger
{
    SaxParserHandler defaultHandler;
   // private ParserManger parserManger;
    private ParserManger(){

    }

    static public ParserManger getParserManger()
    {
        return ParserInstange.parserManger;
    }
    private static class ParserInstange{
        public static final ParserManger parserManger =new ParserManger();
    }

    public  void parseInit(String xmlstring){
        SAXParserFactory factory = SAXParserFactory.newInstance();

        try
        {
            defaultHandler = new SaxParserHandler();
            SAXParser saxParser = factory.newSAXParser();
            XMLReader xr = saxParser.getXMLReader();
            xr.setContentHandler(defaultHandler);
            InputSource inStream = new InputSource();
            inStream.setCharacterStream(new StringReader(xmlstring));
            xr.parse(inStream);
        }
        catch (ParserConfigurationException e)
        {
            e.printStackTrace();
        }
        catch (SAXException e)
        {
            e.printStackTrace();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }
    class SaxParserHandler extends DefaultHandler
    {
        Stack<Maths> stack=new Stack<>();
        private String tempVal,lastMClass;


        @Override
        public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException
        {
            super.startElement(uri, localName, qName, attributes);
            Maths maths=getMaths(localName);
            if (maths!=null&& /*!localName.equalsIgnoreCase("row")&&*/ !localName.equalsIgnoreCase("mi")&& !localName.equalsIgnoreCase("mn")&& !localName.equalsIgnoreCase("mo"))
            {
                stack.add(maths);
                if("mfenced".equalsIgnoreCase(localName))
                {
                   String open= attributes.getValue("open") ,close=attributes.getValue("close");
                    if (open!= null && !open.isEmpty())
                        ((MFenced) maths).open.append(open);
                    else
                        ((MFenced) maths).open.append("opening parenthesis");

                    if (close!= null && !close.isEmpty())
                        ((MFenced) maths).open.append(close);
                    else
                     ((MFenced) maths).close.append("closing parenthesis");
                }
                lastMClass=localName;
            }
            tempVal = "";

        }

        @Override
        public void endElement(String uri, String localName, String qName) throws SAXException
        {
            super.endElement(uri, localName, qName);
            Maths maths=stack.peek();
            if( localName.equalsIgnoreCase("mi")&& localName.equalsIgnoreCase("mn")&& localName.equalsIgnoreCase("mo"))
            {
                if (tempVal != null && !tempVal.trim().isEmpty())
                {
                   // builder.append(tempVal).append(" ");
                    switch (lastMClass)
                    {
                        case "mfrac":
                            ((MFrac)maths).denominator.append(tempVal);
                            ((MFrac)maths).numerator.append(tempVal);  break;
                        case "msqrt":
                            ((MSqrt)maths).builder.append(tempVal);break;
                        case "mroot":
                            ((MRoot)maths).base.append(tempVal);
                            ((MRoot)maths).index.append(tempVal);break;
                       // case "mfenced":((MFenced)maths) ;break;
                        case "msub":
                            ((MSub)maths).base.append(tempVal) ;
                            ((MSub)maths).subscript.append(tempVal) ;break;
                        case "msup":
                            ((MSup)maths).base.append(tempVal) ;
                            ((MSup)maths).superscript.append(tempVal) ;break;
                        case "msubsup":
                            ((MSupSub)maths).base.append(tempVal) ;
                            ((MSupSub)maths).subscript.append(tempVal) ;
                            ((MSupSub)maths).superscript.append(tempVal) ;break;
                        case "munder":
                            ((MUnder)maths).base.append(tempVal) ;
                            ((MUnder)maths).underscript.append(tempVal) ;break;
                        case "mover": ((MOver)maths).base.append(tempVal) ;
                        ((MOver)maths).overscript.append(tempVal) ;break;
                        case "munderover":
                            ((MUnderOver)maths).base.append(tempVal) ;
                            ((MUnderOver)maths).overscript.append(tempVal) ;
                            ((MUnderOver)maths).underscript.append(tempVal) ;break;
                      //  case "mtable": ((MTable)maths). ;break;
                        case "mrow": ((MRow)maths).builder.append(tempVal) ;break;
                    }
                    tempVal="";
                }
            }
            else
            {
                if("mrow".equalsIgnoreCase(localName))
                {

                }
            }
        }

        @Override
        public void characters(char[] ch, int start, int length) throws SAXException
        {
            super.characters(ch, start, length);
            tempVal = new String(ch, start, length);
        }

        Maths getMaths(String localName)
        {
            Maths maths=null;
            switch (localName)
            {
                case "mfrac": maths=new MFrac();break;
                case "msqrt": maths=new MSqrt();break;
                case "mroot": maths=new MRoot();break;
                case "mfenced": maths=new MFenced();break;
                case "msub": maths=new MSub();break;
                case "msup": maths=new MSup();break;
                case "msubsup": maths=new MSupSub();break;
                case "munder": maths=new MUnder();break;
                case "mover": maths=new MOver();break;
                case "munderover": maths=new MUnderOver();break;
                case "mtable": maths=new MTable();break;
                case "mrow": maths=new MRow();break;
            }
            return maths;

        }

    }
    interface Maths{
       public String getString();
    }
    class MSqrt implements Maths{
        StringBuilder builder=new StringBuilder();
        public String getString()
        {
            StringBuilder stringBuilder =new StringBuilder();
            return stringBuilder.toString();
        }
    }
    class MRow implements Maths{
        StringBuilder builder=new StringBuilder();

        public String getString()
        {
            StringBuilder stringBuilder =new StringBuilder(builder);
            return stringBuilder.toString();
        }
    }
    class MTable implements Maths{
        StringBuilder row=new StringBuilder();
        StringBuilder col=new StringBuilder();
        int rowCount,colCount;
        public String getString()
        {
            StringBuilder stringBuilder =new StringBuilder();
            return stringBuilder.toString();
        }
    }
    class MUnderOver implements Maths{
        StringBuilder base=new StringBuilder();
        StringBuilder overscript=new StringBuilder();
        StringBuilder underscript=new StringBuilder();
        public String getString()
        {
            StringBuilder stringBuilder =new StringBuilder();
            return stringBuilder.toString();
        }

    } class MOver implements Maths{
        StringBuilder base=new StringBuilder();
        StringBuilder overscript=new StringBuilder();
        public String getString()
        {
            StringBuilder stringBuilder =new StringBuilder();
            return stringBuilder.toString();
        }

    } class MUnder implements Maths{
        StringBuilder base=new StringBuilder();
        StringBuilder underscript=new StringBuilder();
        public String getString()
        {
            StringBuilder stringBuilder =new StringBuilder();
            return stringBuilder.toString();
        }

    }class MSup implements Maths{
        StringBuilder base=new StringBuilder();
        StringBuilder superscript=new StringBuilder();

        public String getString()
        {
            StringBuilder stringBuilder =new StringBuilder();
            return stringBuilder.toString();
        }

    } class MSupSub implements Maths{
        StringBuilder base=new StringBuilder();
        StringBuilder superscript=new StringBuilder();
        StringBuilder subscript=new StringBuilder();
        public String getString()
        {
            StringBuilder stringBuilder =new StringBuilder();
            return stringBuilder.toString();
        }

    } class MSub implements Maths{
        StringBuilder base=new StringBuilder();
        StringBuilder subscript=new StringBuilder();
        public String getString()
        {
            StringBuilder stringBuilder =new StringBuilder();
            return stringBuilder.toString();
        }

    } class MFenced implements Maths{
        StringBuilder open=new StringBuilder();
        StringBuilder close=new StringBuilder();
        StringBuilder seprator=new StringBuilder();
        public String getString()
        {
            StringBuilder stringBuilder =new StringBuilder();
            return stringBuilder.toString();
        }

    } class MRoot implements Maths{
        StringBuilder base=new StringBuilder();
        StringBuilder index=new StringBuilder();
        public String getString()
        {
            StringBuilder stringBuilder =new StringBuilder();
            return stringBuilder.toString();
        }

    }
    class MFrac implements Maths{
        StringBuilder numerator=new StringBuilder();
        StringBuilder denominator=new StringBuilder();
        public String getString()
        {
            StringBuilder stringBuilder =new StringBuilder();
            return stringBuilder.toString();
        }

    }


}
