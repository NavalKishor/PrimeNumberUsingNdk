package math.reader;

import android.support.annotation.NonNull;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.util.Properties;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import uk.ac.ed.ph.snuggletex.dombuilding.MrowHandler;

public class ParserMangers
{
    SaxParserHandler defaultHandler;

    Properties properties;
   // private ParserManger parserManger;
    private ParserMangers(){
        if(properties==null) properties=new Properties();
    }

    static public ParserMangers getParserManger()
    {
        return ParserInstange.parserManger;
    }
    private static class ParserInstange{
        public static final ParserMangers parserManger =new ParserMangers();
    }

    public  void parseInit(String xmlstring){
        SAXParserFactory factory = SAXParserFactory.newInstance();

        try
        {
            defaultHandler = new SaxParserHandler();
            SAXParser saxParser = factory.newSAXParser();
            XMLReader xr = saxParser.getXMLReader();
            xr.setContentHandler(defaultHandler);
            InputSource inStream = new InputSource();
            inStream.setCharacterStream(new StringReader(xmlstring));
            xr.parse(inStream);
        }
        catch (ParserConfigurationException e)
        {
            e.printStackTrace();
        }
        catch (SAXException e)
        {
            e.printStackTrace();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }
    class SaxParserHandler extends DefaultHandler
    {

        private String tempVal,lastMClass;
        StringBuffer stringBuffer=new StringBuffer();


        @Override
        public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException
        {
            super.startElement(uri, localName, qName, attributes);

            tempVal = "";

        }

        @Override
        public void endElement(String uri, String localName, String qName) throws SAXException
        {
            super.endElement(uri, localName, qName);


        }

        @Override
        public void characters(char[] ch, int start, int length) throws SAXException
        {
            super.characters(ch, start, length);
            tempVal = new String(ch, start, length);
        }



    }

    public Properties getProperties()
    {
        //setProperties(null);

        return properties;
    }

    public void setProperties(Properties properties)
    {
        if(this.properties==null&&properties==null) properties=new Properties();
        //properties.load();
        this.properties = properties;
    }
    public Properties loadMapProperties(Properties properties,InputStream inputStream) throws IOException
    {
        boolean chkclsprop=this.properties==null,chklclprop=properties!=null;
        if(chkclsprop&&chklclprop) this.properties=properties;
        else {
            if(chkclsprop&&!chklclprop) this.properties=new Properties();
        }
        if(inputStream!=null)
            this.properties.load(inputStream);
        if(this.properties.size()<properties.size()) this.properties=properties;
        return properties;
    }
    public static String MMath(Node node)
    {
        StringBuffer stringBuffer= new StringBuffer();
        for (Node child = node.getFirstChild(); child != null; child = child.getNextSibling()) {
           String result= getComplex(child);
           stringBuffer.append(" ").append(result);
        }
        System.out.println("MathResult:["+stringBuffer+"]");
        return stringBuffer.toString().trim();
    }
    public static String MTable(Node node)
    {
        StringBuffer stringBuffer= new StringBuffer();
        for (Node child = node.getFirstChild(); child != null; child = child.getNextSibling()) {
           String result= getComplex(child);
           stringBuffer.append(" ").append(result);
        }
        System.out.println("MathResult:["+stringBuffer+"]");
        return stringBuffer.toString().trim();
    }
    public static String MMatrix(Node node)
    {
        StringBuffer stringBuffer= new StringBuffer();
        stringBuffer.append("matrix is consist of following elements ");
        int i=0;
        for (Node child = node.getFirstChild(); child != null; child = child.getNextSibling()) {
            if(child.getNodeType()!=Node.TEXT_NODE)
            {
                i++;
                stringBuffer.append(" and at row " + i + " of matrix is ");
                String result = getComplex(child);
                stringBuffer.append(result);
            }
        }
        System.out.println("MathResult:["+stringBuffer+"]");
        return stringBuffer.toString().trim();
    }

    public static String MMatrixCol(Node node)
    {
        StringBuffer stringBuffer= new StringBuffer();
        int size=getTotalChildCount(node),i=0;
        size=node.getNodeName().equalsIgnoreCase("mtr")?(size/2):size;
        for (Node child = node.getFirstChild(); child != null; child = child.getNextSibling()) {

            if(child.getNodeType()!=Node.TEXT_NODE)
            {i++;
                String result = getComplex(child);
                result=result.trim();
                String comma = " comma";
                if (size== i|| result.isEmpty()) comma = "";
                stringBuffer.append(" ").append(result).append(comma);
            }
        }
        return stringBuffer.toString().trim();
    }
    public static String MRow(Node node)
    {
        StringBuffer stringBuffer= new StringBuffer();
        for (Node child = node.getFirstChild(); child != null; child = child.getNextSibling()) {
           String result= getComplex(child);
           stringBuffer.append(" ").append(result);
        }
        return stringBuffer.toString().trim();
    }

    public static String MFrac(Node node)
    {
        Element mfrac=(Element)node;
        String open= mfrac.getAttribute("linethickness");

        boolean chkopen=(open==null|| open.isEmpty())?false:open.startsWith("0");
//        linethickness
        StringBuffer stringBuffer= new StringBuffer();
        NodeList mfracList=  node.getChildNodes();
        Node numrator= mfracList.item(0);
        Node numItem= numrator.getChildNodes().item(0);

        stringBuffer.append(chkopen?"from a set of":" fraction of");
        boolean chkNumComplex= getTotalChildCount(numrator)==1;
        if (chkNumComplex)
        {
            String numVal=numItem.getTextContent();
            stringBuffer.append(" ").append(numVal.trim());
//            stringBuffer.append(" numerator as ").append(numVal.trim());
        }
        else
        {
            // complex
            String result= getComplex(numrator);
            stringBuffer.append(" ").append(result);

        }
        stringBuffer.append(chkopen?" elements, the combinations of":" and ");

        Node denominator=mfracList.item(1);
        Node demnoItem= denominator.getChildNodes().item(0);
        String demname=demnoItem.getNodeName();
        boolean chkDemComplex= getTotalChildCount(denominator)==1;
        if (chkDemComplex)
        {
            String demVal=demnoItem.getTextContent();
            stringBuffer.append(" ").append(demVal.trim());
//            stringBuffer.append(" denomerator as ").append(demVal.trim());
        }
        else
        {
            // complex

           String result= getComplex(denominator);
           stringBuffer.append(" ").append(result.trim());
        }
        stringBuffer.append(chkopen?" elements drawn":"");
        return stringBuffer.toString().trim();

    }

    public static String MFenced(Node node)
    {
        StringBuffer stringBuffer = new StringBuffer();
        Element mfence=(Element)node;
        String open= mfence.getAttribute("open");

        open=(open==null|| open.isEmpty())?"(":open;
        open=ParserMangers.getParserManger().properties.getProperty(open,open);
        stringBuffer.append(" ").append((open.trim()));
//            stringBuffer.append(" ").append(properties.getProperty(open));

        String result= getComplex(node.getChildNodes().item(0));

        stringBuffer.append(" ").append(result);
        // closing logic need to decide solved
        String close= mfence.getAttribute("close");
        close=(close==null|| close.isEmpty())?")":close;
        if (!close.equalsIgnoreCase("|")){
            close=ParserMangers.getParserManger().properties.getProperty(close,close);
            stringBuffer.append(" ").append((close.trim()));}
//            stringBuffer.append(" ").append(properties.getProperty(close));

        return stringBuffer.toString().trim();
    }
     public static String MSup(Node node)
    {
        StringBuffer stringBuffer= new StringBuffer();
        NodeList msupList=node.getChildNodes();
       // if (msupList.getLength()==2)
        {


            Node base=msupList.item(0)/*.getChildNodes().item(0)*/;
            boolean chkBaseComplex= getTotalChildCount(base/*msupList.item(0)*/)==1;
            if (chkBaseComplex)
            {
                String baseVal=base.getTextContent().trim();
//                String baseVal=getComplex(base);//change bcz all sigle child operator should me mapped to english
                stringBuffer.append(" ").append(baseVal);
            }
            else
            {
                // complex base will be solve here
                String result= getComplex(base/*msupList.item(0)*/);
                stringBuffer.append(" ").append(result);
            }
            Node powList=msupList.item(1)/*.getChildNodes().item(0)*/;
            boolean chkPowComplex= getTotalChildCount(powList/*msupList.item(1)*/)==1;
            if (chkPowComplex)
            {
                String powVal = powList.getTextContent().trim();
                boolean chkSqr = "2".equalsIgnoreCase(powVal), chkCub = "3".equalsIgnoreCase(powVal);
                if (chkSqr || chkCub)
                {
                    //case of squared and cube
                    if (chkBaseComplex)
                        stringBuffer.append(" ").append(chkSqr ? "squared" : "cube");
                    else
                        stringBuffer.append(" ").append(chkSqr ? "whole squared" : "whole cube");
                }
                else
                {
                    // power is more the the value 3 i.e 4 to n
                    stringBuffer.append(" to the power of ").append(powVal);
                }
            }
            else
            {
                //complex  power
                String result= getComplex(powList/*msupList.item(1)*/);
                stringBuffer.append(" ").append("to the power of ").append(result);
            }
        }
        return stringBuffer.toString().trim();
    } public static String MOver(Node node)
    {
        StringBuffer stringBuffer= new StringBuffer();
        NodeList msupList=node.getChildNodes();
       // if (msupList.getLength()==2)
        {


            Node base=msupList.item(0)/*.getChildNodes().item(0)*/;
            boolean chkBaseComplex= getTotalChildCount(base/*msupList.item(0)*/)==1;
            if (chkBaseComplex)
            {
                String baseVal=base.getTextContent().trim();
//                String baseVal=getComplex(base);//change bcz all sigle child operator should me mapped to english
                stringBuffer.append(" ").append(baseVal);
            }
            else
            {
                // complex base will be solve here
                String result= getComplex(base/*msupList.item(0)*/);
                stringBuffer.append(" ").append(result);
            }
            Node powList=msupList.item(1)/*.getChildNodes().item(0)*/;
            boolean chkPowComplex= getTotalChildCount(powList/*msupList.item(1)*/)==1;
            if (chkPowComplex)
            {
//                String powVal = powList.getTextContent().trim();
                String powVal = getComplex(powList);
                boolean chkSqr = "&#xAF;".equalsIgnoreCase(powVal), chkCub = "^".equalsIgnoreCase(powVal);
                if (chkSqr || chkCub)
                {
                    //case of squared and cube
                    if (chkBaseComplex)
                        stringBuffer.append(" ").append(chkSqr ? "bar" : "hat");
                    else
                        stringBuffer.append(" ").append(chkSqr ? "whole bar" : "whole hat");
                }
                else
                {
                    // power is more the the value 3 i.e 4 to n
                    stringBuffer.append(" ").append(powVal);
                }
            }
            else
            {
                //complex  power
                String result= getComplex(powList/*msupList.item(1)*/);
                stringBuffer.append(" ").append(result);
            }
        }
        return stringBuffer.toString().trim();
    }
    public static String MSqrt(Node node)
    {
        StringBuffer stringBuffer= new StringBuffer();
        NodeList msupList=node.getChildNodes();
       // if (msupList.getLength()==2)
        {

            stringBuffer.append(" square root of ");


            boolean chkBaseComplex= msupList.getLength()==1;

            if (chkBaseComplex)
            {
                String baseVal=node.getTextContent().trim();
                stringBuffer.append(baseVal);
            }
            else
            {
                String result= MRow(node);
                // complex base will be solve here
               // String result= getComplex(msupList.item(0));
                stringBuffer.append(" ").append(result);
            }

        }
        return stringBuffer.toString().trim();
    }
    public static String MSub(Node node)
    {
        StringBuffer stringBuffer= new StringBuffer();
        NodeList msupList=node.getChildNodes();
       // if (msupList.getLength()==2)
        {

            Node base=msupList.item(0)/*.getChildNodes().item(0)*/;

            boolean chkBaseComplex= getTotalChildCount(base/*msupList.item(0)*/)==1;
            if (chkBaseComplex)
            {
                String baseVal=base.getTextContent().trim();
                stringBuffer.append(" ").append(baseVal);
            }
            else
            {
                // complex base will be solve here
                String result= getComplex(base/*msupList.item(0)*/);
                stringBuffer.append(" ").append(result);
            }
            Node powList=msupList.item(1)/*.getChildNodes().item(0)*/;
            boolean chkPowComplex= getTotalChildCount(powList/*msupList.item(1)*/)==1;
            if (chkPowComplex)
            {
                String powVal = powList.getTextContent().trim();
                stringBuffer.append(" ").append("has subscript of ").append(powVal);

            }
            else
            {
                //complex  power
                String result= getComplex(powList/*msupList.item(1)*/);
                stringBuffer.append(" ").append("has subscript of ").append(result);
            }
        }
        return stringBuffer.toString().trim();
    }public static String MUnder(Node node)
    {
        StringBuffer stringBuffer= new StringBuffer();
        NodeList msupList=node.getChildNodes();
       // if (msupList.getLength()==2)
        {

            Node base=msupList.item(0)/*.getChildNodes().item(0)*/;

            boolean chkBaseComplex= getTotalChildCount(base/*msupList.item(0)*/)==1;
            if (chkBaseComplex)
            {
                String baseVal=base.getTextContent().trim();
                stringBuffer.append(" ").append(baseVal);
            }
            else
            {
                // complex base will be solve here
                String result= getComplex(base/*msupList.item(0)*/);
                stringBuffer.append(" ").append(result);
            }
            Node powList=msupList.item(1)/*.getChildNodes().item(0)*/;
            boolean chkPowComplex= getTotalChildCount(powList/*msupList.item(1)*/)==1;
            if (chkPowComplex)
            {
                String powVal = powList.getTextContent().trim();
                stringBuffer.append(" ").append("has lower bound of ").append(powVal);

            }
            else
            {
                //complex  power
                String result= getComplex(powList/*msupList.item(1)*/);
                stringBuffer.append(" ").append("has lower bound of ").append(result);
            }
        }
        return stringBuffer.toString().trim();
    }
    public static String MSubSup(Node node)
    {
        StringBuffer stringBuffer= new StringBuffer();
        NodeList msupList=node.getChildNodes();
       // if (msupList.getLength()==2)
        {

            Node base=msupList.item(0)/*.getChildNodes().item(0)*/;

            boolean chkBaseComplex= getTotalChildCount(base/*msupList.item(0)*/)==1;
            if (chkBaseComplex)
            {
               // String baseVal=base.getTextContent().trim();
                String baseVal=getComplex(base);//change bcz all sigle child operator should me mapped to english
                stringBuffer.append(" ").append(baseVal);
            }
            else
            {
                // complex base will be solve here
                String result= getComplex(base/*msupList.item(0)*/);
                stringBuffer.append(" ").append(result);
            }
            Node subpowList=msupList.item(1)/*.getChildNodes().item(0)*/;

            boolean chksubPowComplex= getTotalChildCount(subpowList/*msupList.item(1)*/)==1;
            if (chksubPowComplex)
            {
                String powVal = subpowList.getTextContent().trim();
                stringBuffer.append(" ").append("has lower bound of ").append(powVal);

            }
            else
            {
                //complex  power
                String result= getComplex(subpowList/*msupList.item(1)*/);
                stringBuffer.append(" ").append("has lower bound of ").append(result);
            }

            Node powList=msupList.item(2)/*.getChildNodes().item(0)*/;

            boolean chkPowComplex= getTotalChildCount(powList/*msupList.item(2)*/)==1;
            if (chkPowComplex)
            {
                String powVal = powList.getTextContent().trim();
                stringBuffer.append(" ").append("and upper bound of ").append(powVal);

            }
            else
            {
                //complex  power
                String result= getComplex(powList/*msupList.item(2)*/);
                stringBuffer.append(" ").append("and upper bound of ").append(result);
            }
        }
        return stringBuffer.toString();
    }
    public static String MUnderOver(Node node)
    {
        StringBuffer stringBuffer= new StringBuffer();
        NodeList msupList=node.getChildNodes();
       // if (msupList.getLength()==2)
        {

            Node base=msupList.item(0)/*.getChildNodes().item(0)*/;

            boolean chkBaseComplex= getTotalChildCount(base/*msupList.item(0)*/)==1;
            if (chkBaseComplex)
            {
               // String baseVal=base.getTextContent().trim();
                String baseVal=getComplex(base);//change bcz all sigle child operator should me mapped to english
                stringBuffer.append(" ").append(baseVal);
            }
            else
            {
                // complex base will be solve here
                String result= getComplex(base/*msupList.item(0)*/);
                stringBuffer.append(" ").append(result);
            }
            Node subpowList=msupList.item(1)/*.getChildNodes().item(0)*/;

            boolean chksubPowComplex= getTotalChildCount(subpowList/*msupList.item(1)*/)==1;
            if (chksubPowComplex)
            {
                String powVal = subpowList.getTextContent().trim();
                stringBuffer.append(" ").append("has lower bound of ").append(powVal);

            }
            else
            {
                //complex  power
                String result= getComplex(subpowList/*msupList.item(1)*/);
                stringBuffer.append(" ").append("has lower bound of ").append(result);
            }

            Node powList=msupList.item(2)/*.getChildNodes().item(0)*/;

            boolean chkPowComplex= getTotalChildCount(powList/*msupList.item(2)*/)==1;
            if (chkPowComplex)
            {
                String powVal = powList.getTextContent().trim();
                stringBuffer.append(" ").append("and upper bound of ").append(powVal);

            }
            else
            {
                //complex  power
                String result= getComplex(powList/*msupList.item(2)*/);
                stringBuffer.append(" ").append("and upper bound of ").append(result);
            }
        }
        return stringBuffer.toString();
    }
    
    public static int getTotalChildCount(Node node)
    {
        int index=((Element)node).getElementsByTagName("*").getLength();
        index=(index==0 && (node.getNodeName().equalsIgnoreCase("mi")||
                node.getNodeName().equalsIgnoreCase("mo")||
                node.getNodeName().equalsIgnoreCase("mn")))?1:index;
        return index;
    }

    public static String getComplex(Node  node)
    {
       // Element element= (Element)node;
        String result="";
        switch (node.getNodeName())
        {
            case "msub":
            case "munder":
                result=ParserMangers.MSub(node);
                break;
            case "mfrac":
                result= ParserMangers.MFrac(node);
                break;
            case "msqrt":
                result=ParserMangers.MSqrt(node);
                break;
            case "mroot":
            case "msup":
            case "mover":
                result= ParserMangers.MSup(node);
                break;
            case "mfenced":result=MFenced(node);
                break;
            case "msubsup":
            case "munderover": result=MSubSup(node); break;
            //case "munder": break;
            case "mtable":/*case "matrix":result=MTable(node); break;*/
            case "matrix":result=MMatrix(node); break;

            case "mrow": /* case "mtr":case "matrixrow":*/result=MRow(node);break;
            case "mtr":   case "matrixrow":result=MMatrixCol(node);break;

            case "mi": case "mo":case "mtd":
            case "mn": case "mtext": case "mstring": case "cn":
                result= node.getTextContent();
                if(node.getNodeName().equalsIgnoreCase("mo"))
                result=getParserManger().properties.getProperty(result,result);

                break;
            case "#text": case "#string":case "string":case "text":result=node.getTextContent();
            result=getParserManger().properties.getProperty(result,result);break;

        }
        return result.trim();
    }
    public static String getComplexChild(Node  node)
    {
       // Element element= (Element)node;
        String result="";
        switch (node.getNodeName())
        {
            case "msub":
            case "munder":
                result=ParserMangers.MSub(node);
                break;
            case "mfrac":
                result= ParserMangers.MFrac(node);
                break;
            case "msqrt":
                result=" square root of";
                break;
            case "mroot":
            case "msup":
            case "mover":
                result= ParserMangers.MSup(node);
                break;
            case "mfenced":result=MFenced(node);
                break;
            case "msubsup":
            case "munderover": result=MSubSup(node); break;
            //case "munder": break;
            case "mtable":result=MTable(node); break;
            case "mrow":result=MRow(node);break;
            case "mi": case "mo":
            case "mn": case "mtext": case "mstring":
                result= node.getChildNodes().item(0).getTextContent();
                break;
            case "#text":result=node.getTextContent();
        }
        return result;
    }





}
