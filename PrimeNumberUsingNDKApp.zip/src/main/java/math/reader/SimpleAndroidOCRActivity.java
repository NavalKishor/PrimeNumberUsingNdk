package math.reader;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Build;
import android.provider.DocumentsContract;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringReader;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Properties;

//import android.app.Activity;
import android.content.Intent;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Scroller;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.googlecode.tesseract.android.TessBaseAPI;

import org.opencv.android.Utils;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import butterknife.BindView;
import butterknife.BindViews;
import butterknife.ButterKnife;
import fmath.conversion.ConvertFromLatexToMathML;
import okhttp3.MediaType;
import okhttp3.RequestBody;
import primeno.naval.com.primenumberusingndk.R;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import uk.ac.ed.ph.snuggletex.SnuggleEngine;
import uk.ac.ed.ph.snuggletex.SnuggleInput;
import uk.ac.ed.ph.snuggletex.SnuggleSession;

public class SimpleAndroidOCRActivity extends AppCompatActivity implements TextToSpeech.OnInitListener,ResponseProcessToParse
{
    //public static final String PACKAGE_NAME = "com.datumdroid.android.ocr.simple";
    public static final String DATA_PATH = Environment
            .getExternalStorageDirectory().toString() + "/SimpleAndroidOCR/";

    // You should have the trained data file in assets folder
    // You can get them at:
    // https://github.com/tesseract-ocr/tessdata
    public static final String lang = "eng";

    private static final String TAG = "SimpleAndroidOCR.java";

    @BindView(R.id.button)
    protected Button _button;
    @BindView(R.id.buttondoOcr)
    protected Button buttondoOcr;
    @BindView(R.id.buttonPhoto)
    protected Button buttonPhoto;
    // protected ImageView _image;
    @BindView(R.id.field)
    protected EditText _field;
    @BindView(R.id.imageView)
    protected ImageView imageView;
    @BindView(R.id.txtResult)
    TextView txtResult;
    protected String _path;
    protected boolean _taken;
    final int REQUEST_CODE_CAPTURE=0;
    final int REQUEST_CODE_LOAD=1;

    protected static final String PHOTO_TAKEN = "photo_taken";
    private Context context;
    Properties properties;
    private TextToSpeech tts;
    MyResponse myResponseInActivity;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        ButterKnife.bind(this);
        context=SimpleAndroidOCRActivity.this;
        //checking the permission
        checkPermission();
        tts = new TextToSpeech(this, this);
        String[] paths = new String[] { DATA_PATH, DATA_PATH + "tessdata/" };

        for (String path : paths) {
            File dir = new File(path);
            if (!dir.exists()) {
                if (!dir.mkdirs()) {
                    Log.v(TAG, "ERROR: Creation of directory " + path + " on sdcard failed");
                    return;
                } else {
                    Log.v(TAG, "Created directory " + path + " on sdcard");
                }
            }

        }

        // lang.traineddata file with the app (in assets folder)
        // You can get them at:
        // http://code.google.com/p/tesseract-ocr/downloads/list
        // This area needs work and optimization
        copyTessData(lang+".traineddata");
//        if (!(new File(DATA_PATH + "tessdata/" + lang + ".traineddata")).exists()) {
//            try {
//
//                AssetManager assetManager = getAssets();
//                InputStream in = assetManager.open("tessdata/" + lang + ".traineddata");
//                //GZIPInputStream gin = new GZIPInputStream(in);
//                OutputStream out = new FileOutputStream(DATA_PATH
//                        + "tessdata/" + lang + ".traineddata");
//
//                // Transfer bytes from in to out
//                byte[] buf = new byte[1024];
//                int len;
//                //while ((lenf = gin.read(buff)) > 0) {
//                while ((len = in.read(buf)) > 0) {
//                    out.write(buf, 0, len);
//                }
//                in.close();
//                //gin.close();
//                out.close();
//
//                Log.v(TAG, "Copied " + lang + " traineddata");
//            } catch (IOException e) {
//                Log.e(TAG, "Was unable to copy " + lang + " traineddata " + e.toString());
//            }
//        }

        copyTessData("eng.cube.bigrams");
//        if (!(new File(DATA_PATH + "tessdata/eng.cube.bigrams")).exists()) {
//            try {
//
//                AssetManager assetManager = getAssets();
//                InputStream in = assetManager.open("tessdata/eng.cube.bigrams");
//                //GZIPInputStream gin = new GZIPInputStream(in);
//                OutputStream out = new FileOutputStream(DATA_PATH
//                        + "tessdata/eng.cube.bigrams");
//
//                // Transfer bytes from in to out
//                byte[] buf = new byte[1024];
//                int len;
//                //while ((lenf = gin.read(buff)) > 0) {
//                while ((len = in.read(buf)) > 0) {
//                    out.write(buf, 0, len);
//                }
//                in.close();
//                //gin.close();
//                out.close();
//
//                Log.v(TAG, "Copied eng.cube.bigrams");
//            } catch (IOException e) {
//                Log.e(TAG, "Was unable to copy eng.cube.bigrams " + e.toString());
//            }
//        }


        // _image = (ImageView) findViewById(R.id.image);
        copyTessData("eng.cube.fold");
        copyTessData("eng.cube.lm");
        copyTessData("eng.cube.nn");
        copyTessData("eng.cube.params");
        copyTessData("eng.cube.size");
        copyTessData("eng.cube.word-freq");
        copyTessData("equ.traineddata");
        copyTessData("eng.traineddata");// duplicate

        _button.setOnClickListener(new ButtonClickHandler());

        _path = DATA_PATH + "/ocr.jpg";
        _field.setScroller(new Scroller(this));
       // _field.setMaxLines(10);
        _field.setVerticalScrollBarEnabled(true);
        _field.setMovementMethod(new ScrollingMovementMethod());
        _field.setOnTouchListener(new View.OnTouchListener() {
            final int DRAWABLE_RIGHT = 2;
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (motionEvent.getAction() == MotionEvent.ACTION_UP){
                    if (motionEvent.getRawX()>=(_field.getRight()-_field.getCompoundDrawables()[DRAWABLE_RIGHT].getBounds().width())){
                        _field.setText("");
                        return true;
                    }
                }
                return false;
            }
        });
        buttondoOcr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                onPhotoTaken();
            }
        });
        buttonPhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);

                startActivityForResult(intent, REQUEST_CODE_LOAD);
            }
        });
        txtResult.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                //myResponseInActivity.
                String text=txtResult.getText().toString();
                speakOut(text);
            }
        });
    }
    private void speakOut(String text)
    {

        //String text = txtResult.getText().toString();
        Toast.makeText(this, "I Am Reading Please wait..", Toast.LENGTH_LONG).show();
        tts.speak(text + " ", TextToSpeech.QUEUE_FLUSH, null);
    }

    @Override
    public void onInit(int status)
    {
        if (status == TextToSpeech.SUCCESS)
        {

            int result = tts.setLanguage(Locale.US);

            if (result == TextToSpeech.LANG_MISSING_DATA
                    || result == TextToSpeech.LANG_NOT_SUPPORTED)
            {
                Log.e("TTS", "This Language is not supported");
            }
            else
            {
                // btnSpeak.setEnabled(true);
               // speakOut();
            }

        }
        else
        {
            Log.e("TTS", "Initilization Failed!");
        }


    }

    @Override
    public void onResponce(MyResponse myResponse)
    {


        if (myResponseInActivity.latex==null||myResponseInActivity.latex.isEmpty()) {

            Toast.makeText(getApplicationContext(), "Some error occurred...", Toast.LENGTH_LONG).show();
            txtResult.setText("Please upload the file again.");
            speakOut("Please upload the file again.");
            return;

        }
        Toast.makeText(getApplicationContext(), "File Uploaded Successfully...", Toast.LENGTH_LONG).show();
//        String mathml = ConvertFromLatexToMathML.convertToMathML(myResponseInActivity.latex);
//        mathml=mathml.replaceAll("[\\n\\s\\t\\r ]","");
//        myResponseInActivity.mathml=mathml==null?"":mathml;
        SnuggleEngine engine = new SnuggleEngine();
        SnuggleSession session = engine.createSession();
        SnuggleInput input = new SnuggleInput("$$ "+myResponseInActivity.latex+" $$");
        try
        {
            session.parseInput(input);

        }
        catch (IOException e1)
        {
            e1.printStackTrace();
        }
        String mathml = session.buildXMLString();
        myResponseInActivity.mathml=mathml==null?"":mathml;
        String result=parseGenerics(mathml);
        progressDoalog.dismiss();
        myResponseInActivity.finalResult=result;
        txtResult.setText(result);

        speakOut(result);
    }

    public class ButtonClickHandler implements View.OnClickListener {
        public void onClick(View view) {
            Log.v(TAG, "Starting Camera app");
            startCameraActivity();
        }
    }

    // Simple android photo capture:
    // http://labs.makemachine.net/2010/03/simple-android-photo-capture/

    protected void startCameraActivity() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            //startActivityForResult(takePictureIntent, REQUEST_CODE_CAPTURE);
            // Create the File where the photo should go
            File photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (IOException ex) {
                // Error occurred while creating the File

            }
            // Continue only if the File was successfully created
            if (photoFile != null) {
                Uri photoURI = FileProvider.getUriForFile(this,
                        "primeno.naval.com.primenumberusingndk.fileProvider",
                        photoFile);
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                startActivityForResult(takePictureIntent, REQUEST_CODE_CAPTURE);
            }
        }
//        File file = new File(_path);
//        Uri outputFileUri = Uri.fromFile(file);
//
        //final Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
//        intent.putExtra(MediaStore.EXTRA_OUTPUT, outputFileUri);
      //  startActivityForResult(intent, 0);
//        captureImage();
    }

    Uri fileUri=null;
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        Log.i(TAG, "resultCode: " + resultCode);

        if (resultCode == -1) {
           // _path=getPath(data.getData());

            switch (requestCode)
            {
                case REQUEST_CODE_CAPTURE:
//                    setPic(imageView);
//                    onPhotoTaken();
                    break;
                case REQUEST_CODE_LOAD:

                             fileUri = data.getData();
                            _path=getFilePathFromURI(this,fileUri);

                    Log.i(TAG,  fileUri.getPath() + "-->onActivityResult:_path: "+_path);
//                            onPhotoTaken();
                    break;
            }
            setPic(imageView);
            onPhotoTaken();
        } else {
            Log.v(TAG, "User cancelled");
        }
    }

    private File createImageFile() throws IOException
    {
            // Create an image file name
            String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
            String imageFileName = "JPEG_" + timeStamp + "_";
            File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
            File image = File.createTempFile(
                    imageFileName,  /* prefix */
                    ".jpg",         /* suffix */
                    storageDir      /* directory */
            );

            // Save a file: path for use with ACTION_VIEW intents
            _path = image.getAbsolutePath();
            return image;

    }
    public void copyTessData(String eng_filename)
    {
        if (!(new File(DATA_PATH + "tessdata/"+eng_filename)).exists()) {
            try {

                AssetManager assetManager = getAssets();
                InputStream in = assetManager.open("tessdata/"+eng_filename);
                //GZIPInputStream gin = new GZIPInputStream(in);
                OutputStream out = new FileOutputStream(DATA_PATH
                        + "tessdata/"+eng_filename);

                // Transfer bytes from in to out
                byte[] buf = new byte[1024];
                int len;
                //while ((lenf = gin.read(buff)) > 0) {
                while ((len = in.read(buf)) > 0) {
                    out.write(buf, 0, len);
                }
                in.close();
                //gin.close();
                out.close();

                Log.v(TAG, "Copied "+eng_filename);
            } catch (IOException e) {
                Log.e(TAG, "Was unable to copy "+eng_filename+" " + e.toString());
            }
        }

    }

    private void galleryAddPic() {
        Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
        File f = new File(_path);
        Uri contentUri = Uri.fromFile(f);
        mediaScanIntent.setData(contentUri);
        this.sendBroadcast(mediaScanIntent);
    }
    private void setPic(ImageView mImageView) {
        // Get the dimensions of the View
        int targetW = mImageView.getWidth();
        int targetH = mImageView.getHeight();

        // Get the dimensions of the bitmap
        BitmapFactory.Options bmOptions = new BitmapFactory.Options();
        bmOptions.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(_path, bmOptions);
        int photoW = bmOptions.outWidth;
        int photoH = bmOptions.outHeight;

        // Determine how much to scale down the image
        int scaleFactor =2;
        try
        {
            if(photoH>targetH||photoW>targetW)
                scaleFactor = Math.min(photoW/targetW, photoH/targetH);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        // Decode the image file into a Bitmap sized to fill the View
        bmOptions.inJustDecodeBounds = false;
        bmOptions.inSampleSize = scaleFactor;
        bmOptions.inPurgeable = true;

        Bitmap bitmap = BitmapFactory.decodeFile(_path, bmOptions);
        mImageView.setImageBitmap(bitmap);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState)
    {
        outState.putBoolean(SimpleAndroidOCRActivity.PHOTO_TAKEN, _taken);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        Log.i(TAG, "onRestoreInstanceState()");
        if (savedInstanceState.getBoolean(SimpleAndroidOCRActivity.PHOTO_TAKEN)) {
            onPhotoTaken();
        }
    }


    private void captureImage() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (intent.resolveActivity(getPackageManager()) != null) {
//            fileTemp = ImageUtils.getOutputMediaFile();
            ContentValues values = new ContentValues(1);
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpg");
            Uri fileUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            _path=fileUri.getPath();
            Log.i(TAG, this.getClass().getSimpleName() + "-->captureImage: "+_path);
//            if (fileTemp != null) {
//            fileUri = Uri.fromFile(fileTemp);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, fileUri);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            startActivityForResult(intent, REQUEST_CODE_CAPTURE);
//            } else {
//                Toast.makeText(this, getString(R.string.error_create_image_file), Toast.LENGTH_LONG).show();
//            }
        } else {
            Toast.makeText(this, "wrong", Toast.LENGTH_LONG).show();
        }
    }
    /**
     * helper to retrieve the path of an image URI
     */

    public static String getFilePathFromURI(Context context, Uri uri) //throws URISyntaxException
    {
        String selection = null;
        String[] selectionArgs = null;
        // Uri is different in versions after KITKAT (Android 4.4), we need to
        if (Build.VERSION.SDK_INT >= 19 && DocumentsContract.isDocumentUri(context.getApplicationContext(), uri)) {
            if (isExternalStorageDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                return Environment.getExternalStorageDirectory() + "/" + split[1];
            } else if (isDownloadsDocument(uri)) {
                final String id = DocumentsContract.getDocumentId(uri);
                uri = ContentUris.withAppendedId(
                        Uri.parse("content://downloads/public_downloads"), Long.valueOf(id));
            } else if (isMediaDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];
                if ("image".equals(type)) {
                    uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                } else if ("video".equals(type)) {
                    uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                } else if ("audio".equals(type)) {
                    uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                }
                selection = "_id=?";
                selectionArgs = new String[]{
                        split[1]
                };
            }
        }
        if ("content".equalsIgnoreCase(uri.getScheme())) {
            String[] projection = {
                    MediaStore.Images.Media.DATA
            };
            Cursor cursor = null;
            try {
                cursor = context.getContentResolver()
                        .query(uri, projection, selection, selectionArgs, null);
                int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
                if (cursor.moveToFirst()) {
                    return cursor.getString(column_index);
                }
            } catch (Exception e) {
            }
        } else if ("file".equalsIgnoreCase(uri.getScheme())) {
            return uri.getPath();
        }
        return null;
    }

    public static boolean isExternalStorageDocument(Uri uri) {
        return "com.android.externalstorage.documents".equals(uri.getAuthority());
    }

    public static boolean isDownloadsDocument(Uri uri) {
        return "com.android.providers.downloads.documents".equals(uri.getAuthority());
    }

    public static boolean isMediaDocument(Uri uri) {
        return "com.android.providers.media.documents".equals(uri.getAuthority());
    }
    TessBaseAPI baseApi;

    protected void onPhotoTaken() {
        _taken = true;

        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = 4;

        Bitmap bitmap = BitmapFactory.decodeFile(_path, options);

        try {
            ExifInterface exif = new ExifInterface(_path);
            int exifOrientation = exif.getAttributeInt(
                    ExifInterface.TAG_ORIENTATION,
                    ExifInterface.ORIENTATION_NORMAL);

            Log.v(TAG, "Orient: " + exifOrientation);

            int rotate = 0;

            switch (exifOrientation) {
                case ExifInterface.ORIENTATION_ROTATE_90:
                    rotate = 90;
                    break;
                case ExifInterface.ORIENTATION_ROTATE_180:
                    rotate = 180;
                    break;
                case ExifInterface.ORIENTATION_ROTATE_270:
                    rotate = 270;
                    break;
            }

            Log.v(TAG, "Rotation: " + rotate);

            if (rotate != 0) {

                // Getting width & height of the given image.
                int w = bitmap.getWidth();
                int h = bitmap.getHeight();

                // Setting pre rotate
                Matrix mtx = new Matrix();
                mtx.preRotate(rotate);

                // Rotating Bitmap
                bitmap = Bitmap.createBitmap(bitmap, 0, 0, w, h, mtx, false);
            }

            // Convert to ARGB_8888, required by tess
            bitmap = bitmap.copy(Bitmap.Config.ARGB_8888, true);

        } catch (IOException e) {
            Log.e(TAG, "Couldn't correct orientation: " + e.toString());
        }

         imageView.setImageBitmap( bitmap );

        Log.v(TAG, "Before baseApi");

      //  if (baseApi==null)
        {
            baseApi = new TessBaseAPI();
            baseApi.setDebug(true);
            baseApi.init(DATA_PATH, lang);
            baseApi.setVariable(TessBaseAPI.VAR_CHAR_WHITELIST, "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+=-[]}{;:'\"\\|~`,./<>?");
            // 黑名单
           // baseApi.setVariable(TessBaseAPI.VAR_CHAR_BLACKLIST, "");
           // baseApi.setPageSegMode(TessBaseAPI.PageSegMode.PSM_AUTO_OSD);
        }

        baseApi.setImage(bitmap);

        String recognizedText = baseApi.getUTF8Text();
        String recognizedTexts = baseApi.getHOCRText(0);

        baseApi.end();

        // You now have the text in recognizedText var, you can do anything with it.
        // We will display a stripped out trimmed alpha-numeric version of it (if lang is eng)
        // so that garbage doesn't make it to the display.

        Log.v(TAG, "OCRED TEXT: " + recognizedText+",recognizedTexts:"+recognizedTexts);

//        if ( lang.equalsIgnoreCase("eng") ) {
//            recognizedText = recognizedText.replaceAll("[^a-zA-Z0-9]+", " ");
//        }

        recognizedText = recognizedText.trim();

        if ( recognizedText.length() != 0 ) {
            _field.setText(_field.getText().toString().length() == 0 ? recognizedText : _field.getText() + " " + recognizedText);
            _field.setSelection(_field.getText().toString().length());
        }
        progressDoalog = new ProgressDialog(this);
        progressDoalog.setCancelable(true);
        progressDoalog.setCanceledOnTouchOutside(true);
        progressDoalog.setMessage("Please wait till we done...Thank you");
        progressDoalog.setProgressStyle(ProgressDialog.STYLE_SPINNER);

        progressDoalog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface)
            {
                dialogInterface.dismiss();
            }
        });
        progressDoalog.show();
       // progressDoalog.setOnDismissListener();
        //call here
        uploadFile(fileUri,_path);
        // Cycle done.
    }
    ProgressDialog progressDoalog ;
    public void doOcr(Bitmap bitmap)
    {

        baseApi.setImage(bitmap);

        String recognizedText = baseApi.getUTF8Text();

        baseApi.end();

        // You now have the text in recognizedText var, you can do anything with it.
        // We will display a stripped out trimmed alpha-numeric version of it (if lang is eng)
        // so that garbage doesn't make it to the display.

        Log.v(TAG, "OCRED TEXT: " + recognizedText);

//        if ( lang.equalsIgnoreCase("eng") ) {
//            recognizedText = recognizedText.replaceAll("[^a-zA-Z0-9]+", " ");
//        }

        recognizedText = recognizedText.trim();

        if ( recognizedText.length() != 0 ) {
            _field.setText(_field.getText().toString().length() == 0 ? recognizedText : _field.getText() + " " + recognizedText);
            _field.setSelection(_field.getText().toString().length());
        }

    }

    // www.Gaut.am was here
    // Thanks for reading!


    private void uploadFile(Uri fileUri,String path) {
      // path= getFilePathFromURI(this,fileUri);
        //creating a file
        File file = new File(path);
        //creating request body for file
        final RequestBody requestFile = RequestBody.create(MediaType.parse(getContentResolver().getType(fileUri)), file);

        //The gson builder
        Gson gson = new GsonBuilder().setLenient().create();
        //creating retrofit object
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Api.BASE_URL_PC_Server)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();
        //creating our api
        Api api = retrofit.create(Api.class);
        //creating a call and calling the upload image method
        Call<MyResponse> call = api.uploadImage(requestFile);
        //finally performing the call
        call.enqueue(new Callback<MyResponse>() {
            @Override
            public void onResponse(Call<MyResponse> call, Response<MyResponse> response) {

                if(response.isSuccessful())
                {
                    myResponseInActivity=response.body();
                    onResponce(myResponseInActivity);

                } else {
                    Log.i(TAG,   "-->onResponse: "+response.toString()+" ,"+response.body());
                    Toast.makeText(getApplicationContext(), "Some error occurred..."+response.toString(), Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<MyResponse> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });


    }
    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    public boolean checkPermission()
    {
        int currentAPIVersion = Build.VERSION.SDK_INT;
        if(currentAPIVersion>=android.os.Build.VERSION_CODES.M)
        {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                if (ActivityCompat.shouldShowRequestPermissionRationale((Activity) context, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                    AlertDialog.Builder alertBuilder = new AlertDialog.Builder(context);
                    alertBuilder.setCancelable(true);
                    alertBuilder.setTitle("Permission necessary");
                    alertBuilder.setMessage("Camera permission is necessary to take a pic!!!");
                    alertBuilder.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                        @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
                        public void onClick(DialogInterface dialog, int which) {
                            ActivityCompat.requestPermissions((Activity)context, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, MY_PERMISSIONS_REQUEST);
                        }
                    });
                    AlertDialog alert = alertBuilder.create();
                    alert.show();
                } else {
                    ActivityCompat.requestPermissions((Activity)context, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.CAMERA,Manifest.permission.WRITE_EXTERNAL_STORAGE}, MY_PERMISSIONS_REQUEST);
                }
                return false;
            } else {
                return true;
            }
        } else {
            return true;
        }
    }

    final int MY_PERMISSIONS_REQUEST=122222;
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    //writeCalendarEvent();
                } else {
                    //code for deny
                }
                break;
        }
    }

    public String parseGenerics(String xmlstring)
    {
        StringBuffer stringBuffer=new StringBuffer();
        try
        {
            //mapping logic

            AssetManager assetManager = getAssets();
            InputStream inputStream = assetManager.open("map.properties");
            ParserMangers.getParserManger().loadMapProperties(null,inputStream);

        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        try
        {
            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
            // InputStream is = getApplicationContext().getAssets().open(xmlstring);
            InputSource is = new InputSource();
             is.setCharacterStream(new StringReader(xmlstring));
            Document document = docBuilder.parse(is);
           // document.getDocumentElement().normalize();
//            Document document = docBuilder.parse(args);
            List<String> singleTextChild= Arrays.asList(new String[]{"math","mi","mo","mn","mtext","mstring"});
            NodeList nodeList = document.getElementsByTagName("*");
            System.out.println("---Node---\n");

            StringBuffer stringBuffer2=new StringBuffer();
            for (int i = 0; i < nodeList.getLength(); i++)
            {
                Node node = nodeList.item(i);
                if (node.getNodeType() == Node.ELEMENT_NODE)
                {
                    // stringBuffer.append(node.getNodeName()).append("->");
                    switch (node.getNodeName())
                    {
                        case "math":
//                            String mMathVal=ParserMangers.MMath(node);
//                            System.out.println("math:"+mMathVal);
                            break;
                        case "mfrac":
                            String result=ParserMangers.MFrac(node);
                            stringBuffer.append(" ").append(result);

                            break;
                        case "msqrt":
                            String mSqrtVal=ParserMangers.MSqrt(node);
                            stringBuffer.append(" ").append(mSqrtVal);
                            break;
                        case "mfenced":
                            String mFenceVal=ParserMangers.MFenced(node);
                            stringBuffer.append(" ").append(mFenceVal);
                           /*
                            NamedNodeMap namedNodeMap=node.getAttributes();
                            if (namedNodeMap.getLength()>=2)
                            {
                                Node mfenceOpen=namedNodeMap.getNamedItem("open");
                                if (mfenceOpen!=null)
                                {
                                    String open=mfenceOpen.getTextContent();
                                    stringBuffer.append(" ").append(properties.getProperty(open));
                                }
                                // closing logic need to decide
                                Node mfenceClose=namedNodeMap.getNamedItem("close");
                                if (mfenceClose!=null)
                                {
                                    String close=mfenceClose.getTextContent();
                                    stringBuffer.append(" ").append(properties.getProperty(close));
                                }
                            }
                            */
                            break;
                        case "munder":
                        case "msub":
                            String msubVal=ParserMangers.MSub(node);
                            stringBuffer.append(" ").append(msubVal);
                            break;
                        case "mroot":
                        case "msup":
                        case "mover":
                            String msupVal=ParserMangers.MSup(node);
                            stringBuffer.append(" ").append(msupVal);
                            break;
                        case "munderover":
                        case "msubsup":
                            String msubsupVal=ParserMangers.MSubSup(node);
                            stringBuffer.append(" ").append(msubsupVal);
                            break;
                        //case "munder": break;
                        //case "mover": break;
                        //case "munderover":break;
                        case "mtable":  String mTableVal=ParserMangers.MTable(node);
                            stringBuffer.append(" ").append(mTableVal);
                            break;
                        case "matrix": String mTabVal=ParserMangers.MMatrix(node);
                            stringBuffer.append(" ").append(mTabVal);
                            break;
                        case "mrow":String mrowVal=ParserMangers.MRow(node);
                            stringBuffer.append(" ").append(mrowVal);
                            break;
                        case "matrixrow":case "mtr": ParserMangers.MMatrixCol(node);break;
                        case "mi": case "mo": case "mn": case "mtext":case "mstring":case "cn":case "mtd":
                        case "#text": case "#string":case "string":case "text":
                            String nodVal=node.getTextContent();
                        if(node.getNodeName().equalsIgnoreCase("mo"))
                            nodVal=properties.getProperty(nodVal,nodVal);
                        stringBuffer.append(" ").append(nodVal);
                        break;
                        case "#comment":break;
                    }
                    //  if(Arrays.asList(new String[]{"mi","mo","mn","mtext","mstring"}).stream().filter(tagName->node.getNodeName().equalsIgnoreCase(tagName)).findAny().isPresent())
                    if(!singleTextChild.contains(node.getNodeName()))
                        i+=ParserMangers.getTotalChildCount(node);
                }

            }
//            System.out.println("nameValue:"+stringBuffer2.toString()+"\n");
            System.out.println("name:"+stringBuffer.toString()+"\n---Node---");

            return stringBuffer.toString();
        }
        catch (ParserConfigurationException e)
        {
            e.printStackTrace();
        }
        catch (SAXException e)
        {
            e.printStackTrace();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        return stringBuffer.toString();
    }


}
 interface ResponseProcessToParse{
    public void onResponce(MyResponse myResponse);
}
