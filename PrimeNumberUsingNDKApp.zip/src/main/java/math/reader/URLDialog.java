package math.reader;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import primeno.naval.com.primenumberusingndk.R;

public class URLDialog extends android.support.v7.app.AppCompatDialogFragment
{
    SharedPreferences prefs;
    public URLDialog() { }

    public static URLDialog newInstance() {
        URLDialog frag = new URLDialog();
       // frag.prefs=prefs;
        return frag;
    }
    public void setPrefs(SharedPreferences prefs)
    {
        this.prefs=prefs;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        final View view = inflater.inflate(R.layout.url_dialog, container);
        getDialog().setTitle(R.string.urltitle);
        EditText e = (EditText) view.findViewById(R.id.editurl);
        e.setText(prefs.getString("MathJaxURL",getResources().getString(R.string.mjurl)));
        Button b = (Button) view.findViewById(R.id.okbutton);
        b.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                EditText e = (EditText) view.findViewById(R.id.editurl);
                fragToActivity.setURL(e.getText().toString());
                getDialog().dismiss();
            }
        });
        Button b1 = (Button) view.findViewById(R.id.defaultbutton);
        b1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                EditText e = (EditText) view.findViewById(R.id.editurl);
                e.setText(getResources().getString(R.string.mjurl));
                fragToActivity.setDefaultURL();
            }
        });
        Button b2 = (Button) view.findViewById(R.id.localbutton);
        b2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                EditText e = (EditText) view.findViewById(R.id.editurl);
                e.setText(getResources().getString(R.string.loopback));
                fragToActivity.setURL(getResources().getString(R.string.loopback));
            }
        });
        return view;//super.onCreateView(inflater, container, savedInstanceState);
    }
    FragToActivityImpl fragToActivity;
    public void setFragToActivity(FragToActivityImpl fragToActivity)
    {
        this.fragToActivity=fragToActivity;
    }
    public interface FragToActivityImpl{
        void setURL(String s);
        void setDefaultURL();
    }
}
