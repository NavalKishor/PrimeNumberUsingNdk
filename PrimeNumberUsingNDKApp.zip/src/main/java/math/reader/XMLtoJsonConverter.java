package math.reader;

import net.sf.json.JSON;
import net.sf.json.xml.XMLSerializer;

import org.apache.commons.io.IOUtils;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

public class XMLtoJsonConverter {
    private URL url = null;
    private InputStream inputStream = null;
    public void getXMLfromJson() {
        try{
            url = XMLtoJsonConverter.class.getClassLoader().getResource("sample.xml");
            inputStream = url.openStream();
            String xml = IOUtils.toString(inputStream);
            JSON objJson = new XMLSerializer().read(xml);
            System.out.println("JSON data : " + objJson);
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            try {
                if (inputStream != null) {
                    inputStream.close();
                }
                url = null;
            } catch (IOException ex) {}
        }
    }
    public void getXMLfromJson(InputStream inputStream) {
        try{

            String xml = IOUtils.toString(inputStream);
            XMLSerializer XmlSerializer = new XMLSerializer();
            JSON objJson =  XmlSerializer.read(xml);
            System.out.println("JSON data : " + objJson);
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            try {
                if (inputStream != null) {
                    inputStream.close();
                }
                url = null;
            } catch (IOException ex) {}
        }
    }
    public String getXMLfromJson(String xml) {

        try{

            JSON  objJson = new XMLSerializer().read(xml);
            System.out.println("JSON data : " + objJson);
            return objJson.toString();
        }catch(Exception e){
            e.printStackTrace();
        }finally{

        }
        return "{}";
    }
    public static void main(String[] args) {
        new XMLtoJsonConverter().getXMLfromJson();
    }
}
